"""Integration checks against a disposable local PHP + MariaDB test fixture.
Never point this at a production app or database. Test setup must be uninstalled.
"""
from pathlib import Path
import re,json,subprocess,os,uuid,datetime,urllib.request,urllib.error,urllib.parse,http.cookiejar

class Response:
    def __init__(self,r):
        self.status_code=r.code;self.headers=r.headers;self.text=r.read().decode('utf-8');self.ok=200<=r.code<300
    def json(self):return json.loads(self.text)
class Session:
    def __init__(self):
        self.cookies=http.cookiejar.CookieJar();self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cookies))
    def _call(self,url,data=None,headers=None):
        try:r=self.opener.open(urllib.request.Request(url,data=data,headers=headers or {}))
        except urllib.error.HTTPError as e:r=e
        return Response(r)
    def get(self,url):return self._call(url)
    def post(self,url,json=None,data=None,headers=None):
        h=dict(headers or {})
        if json is not None:
            h['Content-Type']='application/json';data=__import__('json').dumps(json).encode()
        elif data is not None:
            h['Content-Type']='application/x-www-form-urlencoded';data=urllib.parse.urlencode(data).encode()
        return self._call(url,data,h)
class requests:
    Session=Session

ROOT=Path(__file__).resolve().parents[1]
BASE='http://127.0.0.1:8788'
RUNTIME=ROOT.parent/'php-runtime'
DBCLI=RUNTIME/'root/usr/bin/mariadb'
env=dict(os.environ,LD_LIBRARY_PATH=str(RUNTIME/'root/usr/lib/x86_64-linux-gnu'))
checks=0
def sql(value):
    r=subprocess.run([str(DBCLI),'--no-defaults','--protocol=tcp','-h127.0.0.1','-P33307','-uroot','-N'],input=value,text=True,capture_output=True,env=env,check=True)
    return r.stdout.strip()
def ok(condition,label):
    global checks
    assert condition,label
    checks+=1
class Client:
    def __init__(self):self.s=requests.Session();self.csrf=''
    def init(self):
        r=self.s.get(BASE+'/index.php');assert r.ok,r.text
        self.csrf=re.search(r'name="csrf-token" content="([^"]+)"',r.text).group(1)
        self.cookie_header=r.headers.get('Set-Cookie','')
    def get(self,q=''):return self.s.get(BASE+'/api.php'+q)
    def post(self,v,origin=BASE,csrf=True):
        return self.s.post(BASE+'/api.php',json=v,headers={'Origin':origin,'X-CSRF-Token':self.csrf if csrf else ''})

sql("DROP DATABASE IF EXISTS office_fixture; CREATE DATABASE office_fixture CHARACTER SET utf8mb4; CREATE USER IF NOT EXISTS 'office_fixture'@'127.0.0.1' IDENTIFIED BY 'Fixture-DB-Password42!'; GRANT ALL PRIVILEGES ON office_fixture.* TO 'office_fixture'@'127.0.0.1';")
cfg=ROOT/'upload/office-private/config.php'
if cfg.exists():cfg.unlink()
setup=requests.Session();r=setup.get(BASE+'/setup.php');ok(r.status_code==200,'setup renders')
csrf=re.search(r'name="csrf" value="([^"]+)"',r.text).group(1)
fields={'csrf':csrf,'setup_key':'wrong','app_url':BASE,'db_host':'127.0.0.1','db_port':'33307','db_name':'office_fixture','db_user':'office_fixture','db_password':'Fixture-DB-Password42!','name':'Test Owner','email':'owner@test.example','admin_password':'Fixture-Owner-Password42!','confirm_password':'Fixture-Owner-Password42!'}
r=setup.post(BASE+'/setup.php',data=fields,headers={'Origin':BASE})
ok('Setup key সঠিক নয়।' in r.text and not cfg.exists(),'unknown installer key blocked')
fields['setup_key']=(ROOT/'setup-key.private').read_text()
r=setup.post(BASE+'/setup.php',data=fields,headers={'Origin':BASE})
ok('সেটআপ সম্পন্ন হয়েছে।' in r.text and cfg.exists(),'installer creates schema and owner')
ok(setup.get(BASE+'/setup.php').status_code==410,'installer locked after success')
ok('Fixture-DB-Password42!' not in r.text and 'Fixture-Owner-Password42!' not in r.text,'passwords not reflected')
ok('Fixture-Owner' not in sql('SELECT password_hash FROM office_fixture.od_accounts'),'passwords hashed')
anon=Client();anon.init()
ok(anon.get().status_code==401,'anonymous denied')
ok(anon.get('?registration=1').json()['state']=='signed_out','anonymous gate')
owner=Client();owner.init()
ok(owner.post({'action':'login','email':'owner@test.example','password':'wrong'}).status_code==401,'bad password denied')
ok(owner.post({'action':'login','email':'owner@test.example','password':'Fixture-Owner-Password42!'},csrf=False).status_code==403,'login csrf required')
ok(owner.post({'action':'login','email':'owner@test.example','password':'Fixture-Owner-Password42!'},origin='https://evil.example').status_code==403,'cross origin login denied')
ok(owner.post({'action':'login','email':'owner@test.example','password':'Fixture-Owner-Password42!'}).status_code==200,'owner password login')
ok(owner.get('?registration=1').json()['state']=='approved','owner approved')
data=owner.get().json();ok(data['actor']['role']=='owner' and data['members']==[],'owner empty workspace')
assert isinstance(data['actor']['viewAll'],int)

clients=[]
for n in range(1,4):
    c=Client();c.init();email=f'officer{n}@test.example'
    r=c.post({'action':'signup','email':email,'name':f'Officer {n}','password':'Fixture-Officer-Password42!','role':'owner','is_owner':True})
    ok(r.status_code==200,f'signup {n}')
    ok(c.get('?registration=1').json()['state']=='pending',f'pending state {n}')
    ok(c.get().status_code==403,f'pending work blocked {n}')
    ok(c.post({'action':'member','email':'evil@test.example','name':'Evil','role':'manager','active':True,'viewAll':True,'targets':[]}).status_code==403,f'pending cannot self grant {n}')
    clients.append(c)
one_c,two_c,three_c=clients
ok(one_c.post({'action':'signup','email':'officer1@test.example','name':'Duplicate','password':'Fixture-Officer-Password42!'}).status_code==400,'duplicate signup denied')
requests_data=owner.get().json()['registrations'];ok(len(requests_data)==3,'owner sees requests')
reqs={r['email']:r for r in requests_data}
ok(one_c.post({'action':'approve','requestId':reqs['officer1@test.example']['id'],'name':'Officer 1','role':'manager','viewAll':True,'targets':[]}).status_code==403,'self approval denied')
ok(owner.post({'action':'reject','requestId':reqs['officer3@test.example']['id']}).status_code==200,'owner rejects applicant')
ok(three_c.get('?registration=1').json()['state']=='rejected' and three_c.get().status_code==403,'rejected isolation')
for n in (1,2):
    payload={'action':'approve','requestId':reqs[f'officer{n}@test.example']['id'],'name':f'Officer {n}','role':'officer','viewAll':False,'targets':[]}
    r=owner.post(payload);ok(r.status_code==200,f'approve {n}: {r.text}')
    ok(owner.post(payload).status_code==409,f'repeated approval denied {n}')
for c in (one_c,two_c):ok(c.get('?registration=1').json()['state']=='approved','approval visible')
members={m['email']:m for m in owner.get().json()['members']};m1=members['officer1@test.example'];m2=members['officer2@test.example']
ok(len(members)==2 and one_c.get().json()['actor']['id']==m1['id'],'employee identity bound')
today=owner.get().json()['today'];yesterday=(datetime.date.fromisoformat(today)-datetime.timedelta(days=1)).isoformat();tomorrow=(datetime.date.fromisoformat(today)+datetime.timedelta(days=1)).isoformat()
for m in (m1,m2):
    r=owner.post({'action':'task','title':f"Task {m['name']}",'details':'বাংলা description <script>alert(1)</script>','assigneeId':m['id'],'date':today})
    ok(r.status_code==200,f'assign task {r.text}')
tasks=owner.get().json()['tasks'];t1=next(t for t in tasks if t['assignee_id']==m1['id']);t2=next(t for t in tasks if t['assignee_id']==m2['id'])
r=one_c.get();d=r.json();ok(len(d['tasks'])==1 and d['tasks'][0]['id']==t1['id'],'own task only')
ok(d['members']==[] and d['grants']==[] and d['audit']==[] and d['registrations']==[],'no administrative directory leak')
ok(one_c.get('?task='+t2['id']).status_code==404,'other task detail blocked')
ok(one_c.post({'action':'status','id':t1['id'],'status':'Completed'}).status_code==403,'officer cannot update todo status')
ok(owner.post({'action':'status','id':t1['id'],'status':'Completed'}).status_code==200,'owner status change')
ok(one_c.post({'action':'report','taskId':t2['id'],'date':today,'content':'Bad'}).status_code==404,'other report blocked')
ok(one_c.post({'action':'report','taskId':t1['id'],'date':yesterday,'content':'Backdate'}).status_code==403,'past daily report blocked')
ok(one_c.post({'action':'report','taskId':t1['id'],'date':tomorrow,'content':'Future'}).status_code==403,'future daily report blocked')
for content in ('আজকের রিপোর্ট','Updated report'):
    r=one_c.post({'action':'report','taskId':t1['id'],'date':today,'content':content});ok(r.status_code==200,'today report upsert '+r.text)
detail=one_c.get('?task='+t1['id']).json();ok(len(detail['reports'])==1 and detail['reports'][0]['content']=='Updated report','one report per task and day')
sql("USE office_fixture; UPDATE od_reports SET date='"+yesterday+"';")
ok(one_c.post({'action':'report','taskId':t1['id'],'date':yesterday,'content':'Changed past'}).status_code==403,'existing historical report immutable')
cid=str(uuid.uuid4());comment={'action':'comment','taskId':t1['id'],'content':'Old report comment','requestId':cid}
ok(one_c.post(comment).status_code==200,'comment on historical work')
ok(one_c.post(comment).status_code==200,'comment retry accepted')
ok(len(one_c.get('?task='+t1['id']).json()['comments'])==1,'duplicate comment not appended')
ok(one_c.post({'action':'delete_comment','id':cid}).status_code==400,'no comment delete operation')
ok(one_c.post(comment,origin='https://evil.example').status_code==403,'cross origin mutations denied')
ok(one_c.post(comment,csrf=False).status_code==403,'csrf required')
ok(one_c.get('?task='+urllib.parse.quote("' OR 1=1 --")).status_code==404,'SQL injection in task id blocked')
edit={'action':'member','id':m1['id'],'email':m1['email'],'name':m1['name'],'role':'manager','viewAll':False,'active':True,'targets':[m2['id']]}
ok(owner.post(edit).status_code==200,'selected view grant')
ok(len(one_c.get().json()['tasks'])==2 and one_c.get().json()['actor']['role']=='manager','manager selected view works')
ok(one_c.post({'action':'report','taskId':t2['id'],'date':today,'content':'Cannot impersonate'}).status_code==403,'manager cannot report for others')
ok(one_c.post({'action':'status','id':t2['id'],'status':'Completed'}).status_code==403,'manager cannot change status')
edit['targets']=[]
ok(owner.post(edit).status_code==200 and len(one_c.get().json()['tasks'])==1,'grant removal immediate')
edit['viewAll']=True
ok(owner.post(edit).status_code==200 and len(one_c.get().json()['tasks'])==2,'all view works')
edit['active']=False
ok(owner.post(edit).status_code==200,'deactivation saved')
ok(one_c.get().status_code==401,'deactivation revokes sessions')
ok(one_c.post({'action':'login','email':m1['email'],'password':'Fixture-Officer-Password42!'}).status_code==200,'disabled account can sign in to see blocked screen')
ok(one_c.get('?registration=1').json()['state']=='disabled' and one_c.get().status_code==403,'disabled data denied')
ok(one_c.post({'action':'register','name':'Reactivate'}).status_code==409,'disabled cannot reregister')
edit['active']=True
ok(owner.post(edit).status_code==200 and one_c.get().status_code==200,'owner reactivation')
other_session=Client();other_session.init();ok(other_session.post({'action':'login','email':m2['email'],'password':'Fixture-Officer-Password42!'}).status_code==200,'second employee session')
ok(two_c.post({'action':'change_password','currentPassword':'bad','newPassword':'Fixture-New-Password42!'}).status_code==403,'password change needs current password')
ok(two_c.post({'action':'change_password','currentPassword':'Fixture-Officer-Password42!','newPassword':'Fixture-New-Password42!'}).status_code==200,'password change succeeds')
ok(two_c.get().status_code==200 and other_session.get().status_code==401,'password change revokes other sessions')
edit2={'action':'member','id':m2['id'],'email':m2['email'],'name':m2['name'],'role':'officer','viewAll':False,'active':True,'targets':[],'newPassword':'Fixture-Reset-Password42!'}
ok(owner.post(edit2).status_code==200 and two_c.get().status_code==401,'admin password reset revokes session')
ok(two_c.post({'action':'login','email':m2['email'],'password':'Fixture-Reset-Password42!'}).status_code==200,'reset password login')
pre={'action':'member','email':'preadded@test.example','name':'Preadded','role':'officer','viewAll':True,'active':True,'targets':[]}
ok(owner.post(pre).status_code==200,'owner can preadd employee')
pre_c=Client();pre_c.init();ok(pre_c.post({'action':'signup','email':pre['email'],'name':'Claimed','password':'Fixture-Claim-Password42!'}).status_code==200,'preadded address registers')
ok(pre_c.get('?registration=1').json()['state']=='pending' and pre_c.get().status_code==403,'preadded email claim does not bypass approval')
ok(one_c.post({'action':'logout'}).status_code==200 and one_c.get().status_code==401,'logout clears access')
ok('HttpOnly' in owner.cookie_header and 'SameSite=Lax' in owner.cookie_header,'session cookie flags')
ok(owner.get().headers['X-Content-Type-Options']=='nosniff','security response headers')
print(json.dumps({'checks_passed':checks,'fixture':'PHP 8.3 + MariaDB 10.11','database':'disposable local test database'},ensure_ascii=False))
