import {renderToStaticMarkup} from 'react-dom/server';
import {AuthGate,PasswordChange} from '../source/auth';
import {RegistrationRequests,ApprovalForm} from '../source/registration';
import {createI18n,english} from '../source/translations';
import assert from 'node:assert/strict';
let checks=0;function ok(v:any,msg:string){assert.ok(v,msg);checks++}
for(const language of ['bn','en'] as const){
 for(const state of ['signed_out','pending','disabled','rejected','new'] as const){
  const html=renderToStaticMarkup(<AuthGate access={{state,user:state==='signed_out'?null:{name:'Test officer',email:'officer@example.com'},request:{id:'request',created_at:'2026-11-03T00:00:00Z',reviewed_at:null}}} language={language} languageControl={<select><option>English</option></select>} busy={false} feedback="" onRefresh={()=>{}} onRegister={async()=>{}}/>);
  ok(!html.includes('ChatGPT'),'no platform sign-in wording');
  if(language==='en')ok(!/[\u0980-\u09FF]/.test(html),'English gate has no untranslated Bangla');
  if(state==='signed_out'){ok(html.includes('type="email"')&&html.includes('type="password"'),'email/password fields');ok(!html.includes('signin-with-chatgpt'),'no original auth path')}
 }
 const request={id:'request',name:'Example',email:'example@example.com',status:'pending' as const,created_at:'2026-11-03T00:00:00Z',reviewed_at:null};
 const list=renderToStaticMarkup(<RegistrationRequests requests={[request]} language={language} busy={false} onReview={()=>{}} onReject={()=>{}}/>);
 const approval=renderToStaticMarkup(<ApprovalForm request={request} members={[]} language={language} busy={false} onCancel={()=>{}} onSave={async()=>{}}/>);
 const password=renderToStaticMarkup(<PasswordChange language={language}/>);
 ok(list.includes('example@example.com'),'request email shown to owner');
 ok(approval.includes('example@example.com'),'approval record present');
 ok(password.includes('current-password')&&password.includes('new-password'),'password change forms');
 if(language==='en')ok(!/[\u0980-\u09FF]/.test(list+approval+password),'English admin and password forms translated');
}
const en=createI18n('en');ok(en.t('লগইন ইমেইল')==='Sign-in email','self-declared email label accurate');
ok(en.fmt('2026-11-03').includes('2026'),'locale dates');
console.log(JSON.stringify({render_checks_passed:checks}));
