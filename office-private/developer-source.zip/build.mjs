import {build} from 'esbuild';
import {mkdir,copyFile} from 'node:fs/promises';
await mkdir('upload-assets',{recursive:true});
await build({entryPoints:['source/main.tsx'],bundle:true,format:'esm',jsx:'automatic',minify:true,target:['es2022'],outfile:'upload-assets/app.js',define:{'process.env.NODE_ENV':'"production"'},legalComments:'eof'});
await copyFile('source/app.css','upload-assets/app.css');
console.log('Copy upload-assets/app.js and app.css into the deployed assets/ directory.');
