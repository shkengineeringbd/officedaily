Office Daily — Hostinger PHP/MySQL edition, 1.0.0

Upload archive contents directly into the intended site's public_html folder.
Keep the live Sites application as the reference until migration is verified.
The original Sites application is not modified by this package.

Runtime requirements: PHP 8.2+ with PDO MySQL, mbstring, sessions and password_hash;
MySQL-compatible InnoDB storage supporting utf8mb4; HTTPS; .htaccess support.
No Node.js build or Composer installation is required on the hosting account.

Frontend source: source/*.tsx, source/translations.ts and source/app.css.
To rebuild the browser assets: npm install, then npm run build in this directory.
Copy upload-assets/app.js and app.css into the deployed assets/ directory.
Keep this developer archive under office-private/. Never publish source or secrets.

Backend: complete editable PHP source is shipped in the upload archive itself:
index.php, api.php, setup.php, office-private/bootstrap.php and schema.php.
The installer creates configuration once; subsequent setup requests are locked.
The owner is created only by a valid installer key; registration never grants owner.
Passwords are hashed with PHP password_hash; never store plaintext passwords.
Member emails are self-declared and are not email-verified. Owner approval must
include employee identity checking. SMTP, Google login, email verification and
emailed password recovery are not configured in this edition.

Features: Bengali/English language selector; email/password login; staff registration;
owner approval/rejection and employee records; officer/manager roles; own, selected or
all-task viewing; owner-only assignment/edit/status changes; today's own report edits;
Asia/Dhaka midnight locking; append-only comments; CSV export; password changes;
owner resets staff passwords by editing employee permissions with a new password.
Pre-added email records do not bypass registration approval. Deactivation and
password reset invalidate existing sessions. All writes require same-origin CSRF.

No live database records are included. Existing Sites D1 data has not been migrated.
Do not import the old SQLite/D1 SQL files directly into MySQL. A separate validated
migration is needed if historical data must be retained. New schema uses od_ prefixes.

Verification: PHP syntax and TypeScript checks passed; 83 HTTP integration checks
ran on PHP 8.3 and MariaDB 10.11 against disposable local fixture data; 28 rendered
Bengali/English auth, approval and password-form checks passed. Hostinger deployment
and browser interaction QA have not yet been performed.

tests/integration.py and run_fixture.py document the author's disposable test harness.
They require locally extracted PHP/MariaDB runtime at ../php-runtime with initialized
DB data. Never run this destructive fixture harness against a real application.
The integration harness uses synthetic test passwords only.
tests/render.tsx can be bundled with esbuild for Node and run for markup checks.
